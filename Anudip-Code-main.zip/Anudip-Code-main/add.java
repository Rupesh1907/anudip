import java.util.*;
class add{
    int add(){
    int a = 10;
    int b = 20;
    int sum = a+b;
    return sum;
    }

    public static void main(String[] args) {
        
        add h1 = new add();
        int sum = h1.add();
        System.out.println(sum);
}
}
