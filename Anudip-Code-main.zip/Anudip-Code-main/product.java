import java.util.*;
class prod{
    int ok(){
    int a = 10;
    int b = 20;
    int c = a*b;
    return c;
    }

    public static void main(String[] args) {
        
        prod h1 = new prod();
        int abc = h1.ok();
        System.out.println(abc);
}
}
